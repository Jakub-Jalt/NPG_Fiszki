#!/usr/bin/python
# -*- coding: utf-8 -*-


# zmienne globalne


langchoos = 'null'  # wybor jezyka, polish, englis
typechoos = 1  # 1 - nauka, 2 - wpisywanie, 3 - statysyki, 4 - dodawane fiszek
nick = 'Mateusz'  # nazwa użytkownika
page = 0  # numer strony
positions = 10  # liczba pozycji w pliku z danymi statystycznymi
word = []

words_in_session = 0
pol_in_session = 0
eng_in_session = 0