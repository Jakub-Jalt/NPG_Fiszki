# NPG_Fiszki
Fiszki polsko-angielskie

Dokumentacja projektu zawarta jest w zakładce Wiki.

Projekt realizowany przez: Jakub Jałtuszewski, Mateusz Turek, Marcin Piątek, Igor Kordzi
