#!/usr/bin/python
# -*- coding: utf-8 -*-


import gui


def main():
    gui.app.main()  # uruchomienie gui


if __name__ == "__main__":
    main()
